/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import static javaapplication22.database.DatabaseMenu.JDBC_DRIVER;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class DatabaseKategori {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL      = "jdbc:mysql://localhost/catering";
    static final String USER        = "root";
    static final String PASS        = "";
    
    Connection koneksi;
    Statement statement;
    public DatabaseKategori(){
    try{
            Class.forName(JDBC_DRIVER);
            koneksi = DriverManager.getConnection(DB_URL, USER, PASS);
        }catch (ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertKategori(String id,String nama){
        try{
        String query = "INSERT INTO `jenis`(`id_jenis`, `jenis`) VALUES ('"+id+"','"+nama+"')";
        
        statement = koneksi.createStatement();
        statement.executeUpdate(query);
        System.out.println("Sukses");
        JOptionPane.showMessageDialog(null, "Input Sukses");
        
        
        }catch(SQLException sql){
            System.out.println(sql.getMessage());
        }
    }
    

    
    
}
