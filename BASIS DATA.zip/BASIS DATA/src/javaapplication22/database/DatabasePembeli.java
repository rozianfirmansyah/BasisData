/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication22.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class DatabasePembeli {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL      = "jdbc:mysql://localhost/catering";
    static final String USER        = "root";
    static final String PASS        = "";
    
    Connection koneksi;
    Statement statement;
    public DatabasePembeli(){
    try{
            Class.forName(JDBC_DRIVER);
            koneksi = DriverManager.getConnection(DB_URL, USER, PASS);
        }catch (ClassNotFoundException ex){
            System.out.println(ex.getMessage());
        }catch (SQLException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public void insertPembeli(String id,String nama, String no_telp, String alamat){
        try{
        String query = "INSERT INTO `pembeli`(`ID`, `nama`, `no_telp`, `alamat`) VALUES ('"+id+"','"+nama+"', '"+no_telp+"', '"+alamat+"')";
        
        statement = koneksi.createStatement();
        statement.executeUpdate(query);
        System.out.println("Sukses");
        JOptionPane.showMessageDialog(null, "Input Sukses");
        
        
        }catch(SQLException sql){
            System.out.println(sql.getMessage());
        }
    }
    
}
